import { chromium, expect, Page } from "@playwright/test"
import loginData from "../data/loginCredentials.json"
import { urlConstants } from "../constants/urlConstants"

export class Login{

  page:Page
   
  // url:string
  // username:string
  // password:string

    public selectors={
      userSelector:"#username",
      passwordSelector:"#password",
      loginbutton:".decorativeSubmit",
      crmLink:`//a[text()='CRM/SFA']`,
      leads:{
           LeadsLink:"//a[text()='Leads']"
      },

      accounts:{

      },
      opportunity:{

      }
    }
  

  constructor(page:Page){
    this.page=page
    }  
 
  async navigate(){       
        await this.page.goto(urlConstants.baseUrl)
  }

  async enterCredentials(){
        await this.page.fill(this.selectors.userSelector,loginData.username)
        await this.page.fill(this.selectors.passwordSelector,loginData.password)
  }

  async clickLogin(){
    await this.page.click(this.selectors.loginbutton)
  }

  async verifyTitle(){
    const title=await this.page.title()
     expect(title).toContain("Leaftaps")
  }

}

