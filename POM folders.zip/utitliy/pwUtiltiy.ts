
export abstract class PlaywrightWrapper{
 async fillandEnter(){
   await this
 }

}