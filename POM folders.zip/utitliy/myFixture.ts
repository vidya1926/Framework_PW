import {test as baseTest} from '@playwright/test'
import { Login } from '../pages/LoginPage'
import { HomePage } from '../pages/HomePage'
import { LeadsPage } from '../pages/LeadsPage'


type leaftapsFixture={
    lp:Login
    hp:HomePage
    leadspage:LeadsPage
}

export const test=baseTest.extend<leaftapsFixture>(
    {
  lp:async({page},use)=>{
    const loginPage=new Login(page)
    await loginPage.navigate()
    await loginPage.enterCredentials()
    await loginPage.clickLogin()
    await use(loginPage)
  },

  hp:async({page},use)=>{
       const hompg=new HomePage(page)
       use(hompg)
  },
  leadspage:async({page},use)=>{
    const ledspage=new LeadsPage(page)
    use(ledspage)
  }

})